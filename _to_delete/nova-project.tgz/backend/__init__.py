"""NOVA - Agentic RAG document assistant."""
