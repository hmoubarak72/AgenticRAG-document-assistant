"""Split extracted sections into overlapping chunks, preserving page numbers."""

from __future__ import annotations

from langchain_text_splitters import RecursiveCharacterTextSplitter


def chunk_sections(sections: list[dict], chunk_size: int = 1000, chunk_overlap: int = 150) -> list[dict]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks: list[dict] = []
    for section in sections:
        for piece in splitter.split_text(section["text"]):
            piece = piece.strip()
            if len(piece) >= 20:
                chunks.append({"text": piece, "page": section.get("page")})
    return chunks
