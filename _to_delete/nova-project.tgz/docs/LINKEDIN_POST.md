# LinkedIn post

Most RAG systems follow a straight line:
Question → search the vector database → generate an answer.

But real questions aren't that uniform. Some are general knowledge. Some need private documents. Some return context that doesn't actually answer them. And some are too vague to answer at all.

So I built NOVA, an agentic AI document assistant that decides how to answer before it answers.

It runs as a LangGraph workflow:

1️⃣ Planner: classifies intent as a direct answer, document retrieval, or a clarifying question
2️⃣ Retrieval: turns the request into a semantic query and searches Qdrant
3️⃣ Evidence check: grades whether the chunks are relevant and sufficient, and rewrites the query and retries (with a hard limit) when they aren't
4️⃣ Generator: writes an answer grounded only in that evidence, with citations, and says plainly when the documents don't cover it

In practice:
"What is the capital of France?" → general knowledge, no retrieval.
"What does Section 4.2 of the uploaded policy say about refunds?" → document context needed, retrieving the policy sections.

LangGraph's conditional edges and shared state make each decision explicit, and the UI streams that trace live.

🛠️ FastAPI · LangGraph + LangChain · Groq · Qdrant · local embeddings · PDF/DOCX/XLSX/PPTX ingestion · HTML/CSS/JS

Better AI applications won't come only from bigger models. They'll come from better architecture: systems that plan, check their evidence, and know when not to answer.

Next: hybrid retrieval, reranking, and a larger evaluation set.

🔗 github.com/hmoubarak72/AgenticRAG-document-assistant

#AI #LangGraph #RAG #AgenticAI #LLM #Qdrant #FastAPI #MachineLearning
